$process = $args[0]
$folder = '\\alvjmfwvom001as.corpstg1.jmfamily.com\jmf_fsp_stg\JMFE.ESB.Message\Zeke\Status'

if($process -eq 'GLI')
{
$successfile = $folder + '\InboundGL_Success.xml'
$failurefile = $folder + '\InboundGL_Failure.xml'
$successfilename = 'InboundGL_Success'
$failurefilename = 'InboundGL_Failure'
$timeoutfilename = 'InboundGL_Timeout'
}
 
if($process -eq 'ARBLI')
{
$successfile = $folder + '\InboundARBL_Success.xml'
$failurefile = $folder + '\InboundARBL_Failure.xml'
$successfilename = 'InboundARBL_Success'
$failurefilename = 'InboundARBL_Failure'
$timeoutfilename = 'InboundARBL_Timeout'
}
 
if($process -eq 'XREF')
{
$successfile = $folder + '\InboundXREF_Success.xml'
$failurefile = $folder + '\InboundXREF_Failure.xml'
$successfilename = 'InboundXREF_Success'
$failurefilename = 'InboundXREF_Failure'
$timeoutfilename = 'InboundXREF_Timeout'
}
 
if($process -eq 'GLOGMP11')
{
$successfile = $folder + '\OutboundGLGMP11_Success.xml'
$failurefile = $folder + '\OutboundGLGMP11_Failure.xml'
$successfilename = 'OutboundGLGMP11_Success'
$failurefilename = 'OutboundGLGMP11_Failure'
$timeoutfilename = 'OutboundGLGMP11_Timeout'
}
 
if($process -eq 'ARBLO')
{
$successfile = $folder + '\OutboundARClosedItems_Success.xml'
$failurefile = $folder + '\OutboundARClosedItems_Failure.xml'
$successfilename = 'OutboundARClosedItems_Success'
$failurefilename = 'OutboundARClosedItems_Failure'
$timeoutfilename = 'OutboundARClosedItems_Timeout'
}
 
if($process -eq 'ST')
{
$successfile = $folder + '\InboundSalesTax_Success.xml'
$failurefile = $folder + '\InboundSalesTax_Failure.xml'
$successfilename = 'InboundSalesTax_Success'
$failurefilename = 'InboundSalesTax_Failure'
$timeoutfilename = 'InboundSalesTax_Timeout'
}
 
if($process -eq 'GLOAU')
{
$successfile = $folder + '\AUXREF_Success.xml'
$failurefile = $folder + '\AUXREF_Failure.xml'
$successfilename = 'AUXREF_Success'
$failurefilename = 'AUXREF_Failure'
$timeoutfilename = 'AUXREF_Timeout'
}

if($process -eq 'CMBA')
{
$successfile = $folder + '\InboundCMBankBoA_Success.xml'
$failurefile = $folder + '\InboundCMBankBoA_Failure.xml'
$successfilename = 'InboundCMBankBoA_Success'
$failurefilename = 'InboundCMBankBoA_Failure'
$timeoutfilename = 'InboundCMBankBoA_Timeout'
}

if($process -eq 'CMWF')
{
$successfile = $folder + '\InboundCMBankWF_Success.xml'
$failurefile = $folder + '\InboundCMBankWF_Failure.xml'
$successfilename = 'InboundCMBankWF_Success'
$failurefilename = 'InboundCMBankWF_Failure'
$timeoutfilename = 'InboundCMBankWF_Timeout'
}

if($process -eq 'APIStub')
{
$successfile = $folder + '\InboundAPStub_Success.xml'
$failurefile = $folder + '\InboundAPStub_Failure.xml'
$successfilename = 'InboundAPStub_Success'
$failurefilename = 'InboundAPStub_Failure'
$timeoutfilename = 'InboundAPStub_Timeout'
}

if($process -eq 'APIInv1MF')
{
$successfile = $folder + '\InboundAPInvoiceMF_Success.xml'
$failurefile = $folder + '\InboundAPInvoiceMF_Failure.xml'
$successfilename = 'InboundAPInvoiceMF_Success'
$failurefilename = 'InboundAPInvoiceMF_Failure'
$timeoutfilename = 'InboundAPInvoiceMF_Timeout'
}

if($process -eq 'APIInv1VB')
{
$successfile = $folder + '\InboundAPInvoiceVB_Success.xml'
$failurefile = $folder + '\InboundAPInvoiceVB_Failure.xml'
$successfilename = 'InboundAPInvoiceVB_Success'
$failurefilename = 'InboundAPInvoiceVB_Failure'
$timeoutfilename = 'InboundAPInvoiceVB_Timeout'
}

if($process -eq 'APIVendAdd')
{
$successfile = $folder + '\InboundAPVendAdd_Success.xml'
$failurefile = $folder + '\InboundAPVendAdd_Failure.xml'
$successfilename = 'InboundAPVendAdd_Success'
$failurefilename = 'InboundAPVendAdd_Failure'
$timeoutfilename = 'InboundAPVendAdd_Timeout'
}

if($process -eq 'APIVendUpd')
{
$successfile = $folder + '\InboundAPVendUpd_Success.xml'
$failurefile = $folder + '\InboundAPVendUpd_Failure.xml'
$successfilename = 'InboundAPVendUpd_Success'
$failurefilename = 'InboundAPVendUpd_Failure'
$timeoutfilename = 'InboundAPVendUpd_Timeout'
}

if($process -eq 'CDC')
{
$successfile = $folder + '\InboundCDCBatch_Success.xml'
$failurefile = $folder + '\InboundCDCBatch_Failure.xml'
$successfilename = 'InboundCDCBatch_Success'
$failurefilename = 'InboundCDCBatch_Failure'
$timeoutfilename = 'InboundCDCBatch_Timeout'
}

if($process -eq 'APIInv2')
{
$successfile = $folder + '\InboundAPInvoicePart2_Success.xml'
$failurefile = $folder + '\InboundAPInvoicePart2_Failure.xml'
$successfilename = 'InboundAPInvoicePart2_Success'
$failurefilename = 'InboundAPInvoicePart2_Failure'
$timeoutfilename = 'InboundAPInvoicePart2_Timeout'
}

if($process -eq 'GLOGWP12')
{
$successfile = $folder + '\OutboundGLGWP12_Success.xml'
$failurefile = $folder + '\OutboundGLGWP12_Failure.xml'
$successfilename = 'OutboundGLGWP12_Success'
$failurefilename = 'OutboundGLGWP12_Failure'
$timeoutfilename = 'OutboundGLGWP12_Timeout'
}

if($process -eq 'APOPmtVoids')
{
$successfile = $folder + '\OutboundAPVoids_Success.xml'
$failurefile = $folder + '\OutboundAPVoids_Failure.xml'
$successfilename = 'OutboundAPVoids_Success'
$failurefilename = 'OutboundAPVoids_Failure'
$timeoutfilename = 'OutboundAPVoids_Timeout'
}

if($process -eq 'APOPmtChk')
{
$successfile = $folder + '\OutboundAPCheck_Success.xml'
$failurefile = $folder + '\OutboundAPCheck_Failure.xml'
$successfilename = 'OutboundAPCheck_Success'
$failurefilename = 'OutboundAPCheck_Failure'
$timeoutfilename = 'OutboundAPCheck_Timeout'
}

if($process -eq 'APOPmtACH')
{
$successfile = $folder + '\OutboundAPACH_Success.xml'
$failurefile = $folder + '\OutboundAPACH_Failure.xml'
$successfilename = 'OutboundAPACH_Success'
$failurefilename = 'OutboundAPACH_Failure'
$timeoutfilename = 'OutboundAPACH_Timeout'
}

if($process -eq 'APOReconJMA')
{
$successfile = $folder + '\JMAReconChecks_Success.xml'
$failurefile = $folder + '\JMAReconChecks_Failure.xml'
$successfilename = 'JMAReconChecks_Success'
$failurefilename = 'JMAReconChecks_Failure'
$timeoutfilename = 'JMAReconChecks_Timeout'
}

if($process -eq 'APOReconSET')
{
$successfile = $folder + '\OutboundAPReconCheckSET_Success.xml'
$failurefile = $folder + '\OutboundAPReconCheckSET.xml'
$successfilename = 'OutboundAPReconCheckSET_Success'
$failurefilename = 'OutboundAPReconCheckSET_Failure'
$timeoutfilename = 'OutboundAPReconCheckSET_Timeout'
}

if($process -eq 'APOPmtAbP')
{
$successfile = $folder + '\OutboundAPPosPayBoA_Success.xml'
$failurefile = $folder + '\OutboundAPPosPayBoA_Failure.xml'
$successfilename = 'OutboundAPPosPayBoA_Success'
$failurefilename = 'OutboundAPPosPayBoA_Failure'
$timeoutfilename = 'OutboundAPPosPayBoA_Timeout'
}

if($process -eq 'FTPPosBA')
{
$successfile = $folder + '\FTPPosBA_Success.xml'
$failurefile = $folder + '\FTPPosBA_Failure.xml'
$successfilename = 'FTPPosBA_Success'
$failurefilename = 'FTPPosBA_Failure'
$timeoutfilename = 'FTPPosBA_Timeout'
}

if($process -eq 'FTPPosWF')
{
$successfile = $folder + '\FTPPosWF_Success.xml'
$failurefile = $folder + '\FTPPosWF_Failure.xml'
$successfilename = 'FTPPosWF_Success'
$failurefilename = 'FTPPosWF_Failure'
$timeoutfilename = 'FTPPosWF_Timeout'
}

if($process -eq 'FTPVendUpd')
{
$successfile = $folder + '\FTPVendUpd_Success.xml'
$failurefile = $folder + '\FTPVendUpd_Failure.xml'
$successfilename = 'FTPVendUpd_Success'
$failurefilename = 'FTPVendUpd_Failure'
$timeoutfilename = 'FTPVendUpd_Timeout'
}
 
if($process -eq 'FTPVoidsiVOS')
{
$successfile = $folder + '\FTPVoidsiVOS_Success.xml'
$failurefile = $folder + '\FTPVoidsiVOS_Failure.xml'
$successfilename = 'FTPVoidsiVOS_Success'
$failurefilename = 'FTPVoidsiVOS_Failure'
$timeoutfilename = 'FTPVoidsiVOS_Timeout'
}
 
if($process -eq 'FTPVoidsJMA')
{
$successfile = $folder + '\FTPVoidsJMA_Success.xml'
$failurefile = $folder + '\FTPVoidsJMA_Failure.xml'
$successfilename = 'FTPVoidsJMA_Success'
$failurefilename = 'FTPVoidsJMA_Failure'
$timeoutfilename = 'FTPVoidsJMA_Timeout'
}
 
if($process -eq 'FTPVoidsRC')
{
$successfile = $folder + '\FTPVoidsRC_Success.xml'
$failurefile = $folder + '\FTPVoidsRC_Failure.xml'
$successfilename = 'FTPVoidsRC_Success'
$failurefilename = 'FTPVoidsRC_Failure'
$timeoutfilename = 'FTPVoidsRC_Timeout'
}

if($process -eq 'FTPVoidsTMC')
{
$successfile = $folder + '\FTPVoidsTMC_Success.xml'
$failurefile = $folder + '\FTPVoidsTMC_Failure.xml'
$successfilename = 'FTPVoidsTMC_Success'
$failurefilename = 'FTPVoidsTMC_Failure'
$timeoutfilename = 'FTPVoidsTMC_Timeout'
}

if($process -eq 'FTPBankBA')
{
$successfile = $folder + '\FTPBankBA_Success.xml'
$failurefile = $folder + '\FTPBankBA_Failure.xml'
$successfilename = 'FTPBankBA_Success'
$failurefilename = 'FTPBankBA_Failure'
$timeoutfilename = 'FTPBankBA_Timeout'
}

if($process -eq 'FTPBankWF')
{
$successfile = $folder + '\FTPBankWF_Success.xml'
$failurefile = $folder + '\FTPBankWF_Failure.xml'
$successfilename = 'FTPBankWF_Success'
$failurefilename = 'FTPBankWF_Failure'
$timeoutfilename = 'FTPBankWF_Timeout'
}

if($process -eq 'FTPAPINFOiVOS')
{
$successfile = $folder + '\FTPAPINFOiVOS_Success.xml'
$failurefile = $folder + '\FTPAPINFOiVOS_Failure.xml'
$successfilename = 'FTPAPINFOiVOS_Success'
$failurefilename = 'FTPAPINFOiVOS_Failure'
$timeoutfilename = 'FTPAPINFOiVOS_Timeout'
}

if($process -eq 'FTPAPINFORC')
{
$successfile = $folder + '\FTPAPINFORC_Success.xml'
$failurefile = $folder + '\FTPAPINFORC_Failure.xml'
$successfilename = 'FTPAPINFORC_Success'
$failurefilename = 'FTPAPINFORC_Failure'
$timeoutfilename = 'FTPAPINFORC_Timeout'
}

if($process -eq 'FTPAPINFOTMC')
{
$successfile = $folder + '\FTPAPINFOTMC_Success.xml'
$failurefile = $folder + '\FTPAPINFOTMC_Failure.xml'
$successfilename = 'FTPAPINFOTMC_Success'
$failurefilename = 'FTPAPINFOTMC_Failure'
$timeoutfilename = 'FTPAPINFOTMC_Timeout'
}

if($process -eq 'FTPAPINFOJMA')
{
$successfile = $folder + '\FTPAPINFOJMA_Success.xml'
$failurefile = $folder + '\FTPAPINFOJMA_Failure.xml'
$successfilename = 'FTPAPINFOJMA_Success'
$failurefilename = 'FTPAPINFOJMA_Failure'
$timeoutfilename = 'FTPAPINFOJMA_Timeout'
}

if($process -eq 'APOInfoSort')
{
$successfile = $folder + '\OutboundAPInfoSort_Success.xml'
$failurefile = $folder + '\OutboundAPInfoSort_Failure.xml'
$successfilename = 'OutboundAPInfoSort_Success'
$failurefilename = 'OutboundAPInfoSort_Failure'
$timeoutfilename = 'OutboundAPInfoSort_Timeout'
}

if($process -eq 'APOInvoiceToMQ')
{
$successfile = $folder + '\OutboundAPInvoiceToMQ_Success.xml'
$failurefile = $folder + '\OutboundAPInvoiceToMQ_Failure.xml'
$successfilename = 'OutboundAPInvoiceToMQ_Success'
$failurefilename = 'OutboundAPInvoiceToMQ_Failure'
$timeoutfilename = 'OutboundAPInvoiceToMQ_Timeout'
}

if($process -eq 'PgmDate')
{
$successfile = $folder + '\InboundPgmDate_Success.xml'
$failurefile = $folder + '\InboundPgmDate_Failure.xml'
$successfilename = 'InboundPgmDate_Success'
$failurefilename = 'InboundPgmDate_Failure'
$timeoutfilename = 'InboundPgmDate_Timeout'
}

if($process -eq 'LawBkp')
{
$successfile = $folder + '\InboundLawsonBackup_Success.xml'
$failurefile = $folder + '\InboundLawsonBackup_Failure.xml'
$successfilename = 'InboundLawsonBackup_Success'
$failurefilename = 'InboundLawsonBackup_Failure'
$timeoutfilename = 'InboundLawsonBackup_Timeout'
}

$destination = $folder + '\Archive\'
$timeoutFolder = $folder + '\Archive\Timeout\'
$status = 9
$timeout = 0
 
do
{
Start-Sleep -Seconds 10
 
if (Test-Path($successfile))
{
$status = 0
$currentdate =  Get-Date -Format yyyyMMddHHmmss
$destination = $destination + $successfilename + $currentdate  + '.xml'
Move-Item $successfile -Destination $destination -Force #-Verbose # Force will overwrite files with same name
}
 
if (Test-Path($failurefile))
{
$status = 1
$currentdate =  Get-Date -Format yyyyMMddHHmmss
$destination = $destination  + $failurefilename + $currentdate  + '.xml'
Move-Item $failurefile -Destination $destination -Force #-Verbose # Force will overwrite files with same name
}
 
if($timeout -gt 10800)
{
$status = 1
$currentdate =  Get-Date -Format yyyyMMddHHmmss
$archiveFolderName =  Get-Date -Format yyyyMMdd
$timeoutFolder = $timeoutFolder  + $archiveFolderName + '\' + $timeoutfilename + $currentdate  + '.xml'
New-Item $timeoutFolder -type file -Force #-Verbose # Force will overwrite files with same name
}
 
$timeout = $timeout + 10
 
}while($status -gt 8)
 
EXIT $status
 